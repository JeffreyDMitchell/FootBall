package football;


public class Goal 
{

	int x, y, rad;
	
	public Goal(int x, int y)
	{
		
		this.x = x;
		this.y = y;
		
		rad = 100;
		
	}
	
}
